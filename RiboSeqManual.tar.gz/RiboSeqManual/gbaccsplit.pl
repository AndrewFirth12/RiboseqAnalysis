#!/usr/bin/perl
    
open(infile, "sequence.gb");
my $firsttime = 1;
my $gotname = 0;
my $name = "junk.txt";

while (<infile>) {
    chomp;
    if ($_ =~ "^LOCUS ") {
	if ($firsttime) {
	    open(outfile, ">temp0");
	    $firsttime = 0;
	    $gotname = 0;
	} else {
	    close outfile;
	    if ($gotname) {
		system "mv", "temp0", $name.".gb";
	    } else {
		system "mv", "temp0", "junk.txt";
	    }
	    open(outfile, ">temp0");
	    $gotname = 0;
	}
    }
    if ($_ =~ "^ACCESSION ") {
        $name = $_ ;
        $name =~ s/^ACCESSION\s+//;
        $name =~ s/\s.*$//;
	$gotname = 1;
    }
    print outfile $_ , "\n";
}
  close outfile;
if ($gotname) {
    system "mv", "temp0", $name.".gb";
} else {
    system "mv", "temp0", "junk.txt";
}
