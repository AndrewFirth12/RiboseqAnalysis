#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <cstring>
using namespace std;
#define maxlength 50000

int main(int argc, char* argv[])
{

  int nreads, i, j, k, nt, seq[maxlength][6], reflen, refseq[maxlength][5];
  double ucag[maxlength][5], threshold;
  char read[1000], refnt[1000], exp;

  if (2 != argc) {
    cerr << "Usage '" << argv[0] << " threshold'.\n";
    exit(EXIT_FAILURE);
  }
  threshold = atof(argv[1]);

  // Initialize matrix.
  for (k = 0; k < maxlength; ++k) {
    seq[k][0] = seq[k][1] = seq[k][2] = seq[k][3] = seq[k][4] = seq[k][5] = 0;
    refseq[k][0] = refseq[k][1] = refseq[k][2] = refseq[k][3] = refseq[k][4]
      = 0;
    ucag[k][0] = ucag[k][1] = ucag[k][2] = ucag[k][3] = ucag[k][4] = 0;
  }


  // Read refseq.txt.
  ifstream refseqfile("refseq.txt");
  if (!refseqfile) {
    cerr << "Aborting: Can't find file 'refseq.txt'.\n";
    exit(EXIT_FAILURE);
  }
  reflen = -1;
  while (refseqfile.ignore(1000, '\n')) {
    ++reflen;
  }
  refseqfile.clear();
  refseqfile.seekg(0);
  cerr << "Reference sequence length " << reflen << " nt.\n";

  for (k = 0; k < reflen; ++k) {
    refseqfile >> refnt;
    refseqfile.ignore(1000, '\n');
    if (refnt[0] == 'U' || refnt[0] == 'u') {
      refseq[k][0] += 1;
    }
    else if (refnt[0] == 'T' || refnt[0] == 't') {
      refseq[k][0] += 1;
    }
    else if (refnt[0] == 'C' || refnt[0] == 'c') {
      refseq[k][1] += 1;
    }
    else if (refnt[0] == 'A' || refnt[0] == 'a') {
      refseq[k][2] += 1;
    }
    else if (refnt[0] == 'G' || refnt[0] == 'g') {
      refseq[k][3] += 1;
    }
    else if (refnt[0] == 'N' || refnt[0] == 'n') {
      refseq[k][4] += 1;
    }
    else {
      cerr << "Bad character found: " << refnt[0] << "\n";
    }
  }

  // Number of reads in bowtie.txt.
  ifstream readsfile("bowtie.txt");
  if (!readsfile) {
    cerr << "Aborting: Can't find file 'bowtie.txt'.\n";
    exit(EXIT_FAILURE);
  }
  nreads = -1;
  while (readsfile.ignore(1000, '\n')) {
    ++nreads;
  }
  readsfile.clear();
  readsfile.seekg(0);
  cerr << "Found " << nreads << " reads.\n";

  for (k = 0; k < nreads; ++k) {
    readsfile >> nt;
    readsfile >> read;
    readsfile.ignore(1000, '\n');
    for (i = 0; ; ++i) {
      if (read[i] == 'U' || read[i] == 'u') {
	seq[nt+i][0] += 1;
      }
      else if (read[i] == 'T' || read[i] == 't') {
	seq[nt+i][0] += 1;
      }
      else if (read[i] == 'C' || read[i] == 'c') {
	seq[nt+i][1] += 1;
      }
      else if (read[i] == 'A' || read[i] == 'a') {
	seq[nt+i][2] += 1;
      }
      else if (read[i] == 'G' || read[i] == 'g') {
	seq[nt+i][3] += 1;
      }
      else if (read[i] == 'N' || read[i] == 'n') {
        seq[nt+i][4] += 1;
      }
      else if (read[i] == '\0') {      
	break;
      }
      else {
	cerr << "Bad character found: " << read[i] << "\n";
      }
    }
    /*
    cerr << nt << " " << read << " "  << readlen << "\n";
    for (i = 0; i < readlen; ++i) {
      cerr << test[i] << ",";
    }
    cerr << "\n";
    */

  }

  // Total counts at each nt position
  for (k = 0; k < reflen; ++k) {
    seq[k][5] = seq[k][0] + seq[k][1] + seq[k][2] + seq[k][3] + seq[k][4];
  }

  // UCAG%s
  for (k = 0; k < reflen; ++k) {
    for (j = 0; j < 5; ++j) {
      if (0 != seq[k][5]) {
        ucag[k][j] = float(seq[k][j]) / float(seq[k][5]);
      } else {
	ucag[k][j] = 0;
      }
    }
  }

  /*
  for (k = 0; k < reflen; ++k) {
    cout << k << " " << ucag[k][0] << " " << ucag[k][1] << " " << ucag[k][2]
	 << " " << ucag[k][3] << " " << ucag[k][4] << " ";  
    cout << " " << refseq[k][0] << " " << refseq[k][1] << " " << refseq[k][2]
	 << " " << refseq[k][3] << " " << refseq[k][4] << "\n";  
  }
  */

  for (k = 0; k < reflen; ++k) {
    cout << k+1 << " " << seq[k][5] << " "
	 << ucag[k][0] - float(refseq[k][0]) << " " 
	 << ucag[k][1] - float(refseq[k][1]) << " " 
	 << ucag[k][2] - float(refseq[k][2]) << " " 
	 << ucag[k][3] - float(refseq[k][3]) << " " 
	 << ucag[k][4] - float(refseq[k][4]) << "\n"; 
  }

  for (k = 0; k < reflen; ++k) {
    if (1 == refseq[k][0]) {
      exp = 'U';
    } else if (1 == refseq[k][1]) {
      exp = 'C';
    } else if (1 == refseq[k][2]) {
      exp = 'A';
    } else if (1 == refseq[k][3]) {
      exp = 'G';
    } else {
      exp = 'N';
    }
    if (ucag[k][0] - float(refseq[k][0]) >= threshold) {
      cerr << "Nucleotide " << k+1 << " [" << seq[k][5] << " reads]: expected " 
	   << exp << "; found " << ucag[k][0]*100 << "% U.\n";
    }
    if (ucag[k][1] - float(refseq[k][1]) >= threshold) {
      cerr << "Nucleotide " << k+1 << " [" << seq[k][5] << " reads]: expected " 
	   << exp << "; found " << ucag[k][1]*100 << "% C.\n";
    }
    if (ucag[k][2] - float(refseq[k][2]) >= threshold) {
      cerr << "Nucleotide " << k+1 << " [" << seq[k][5] << " reads]: expected " 
	   << exp << "; found " << ucag[k][2]*100 << "% A.\n";
    }
    if (ucag[k][3] - float(refseq[k][3]) >= threshold) {
      cerr << "Nucleotide " << k+1 << " [" << seq[k][5] << " reads]: expected " 
	   << exp << "; found " << ucag[k][3]*100 << "% G.\n";
    }
    if (ucag[k][4] - float(refseq[k][4]) >= threshold) {
      cerr << "Nucleotide " << k+1 << " [" << seq[k][5] << " reads]: expected " 
	   << exp << "; found " << ucag[k][4]*100 << "% N.\n";
    }
  }


}
