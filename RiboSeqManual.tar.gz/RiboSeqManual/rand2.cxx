#include <iostream>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <cstring>
using namespace std;

int main(int argc, char* argv[])
{

  if (3 != argc) {
    cerr << "Usage '" << argv[0] << " seed nrand'.\n";
    exit(EXIT_FAILURE);
  }

  int i;
  double s1;
  int seed = atoi(argv[1]);
  int nrand = atoi(argv[2]);

  srand(seed);

  for (i = 0; i < nrand; ++i) {
    s1 = float(rand())/float(RAND_MAX);
    cout << s1 << "\n";
  }

}
