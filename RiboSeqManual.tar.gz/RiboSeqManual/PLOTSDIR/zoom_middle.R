y_fwd = 0
y_rev = 0
if (file.info("HistFiles0/lll.fwd")$size != 0) {
  fwd <- read.table("HistFiles0/lll.fwd")
  y_fwd = 1
}
if (file.info("HistFiles0/lll.rev")$size != 0) {
  rev <- read.table("HistFiles0/lll.rev")
  y_rev = 1
}
t_fwd = vvf
t_rev = vvr

o1 = -1*ccc + 0.3

if (y_fwd) {
  sc = 1.05*max(fwd$V1)
} else {
  sc = 1
}
yh = signif(0.8*max(fwd$V1),digits=2)

if (y_fwd & t_fwd) {
  rect(segoffsets[fwd$V3]+(fwd$V2+offset+0.5)/ntperinch,o1,segoffsets[fwd$V3]+(fwd$V2+offset-0.5)/ntperinch,o1+fwd$V1/sc,col=col3[(fwd$V2+phaseoffset)%%3+1],border=FALSE)
}
if (y_rev & t_rev) {
  rect(segoffsets[rev$V3]+(rev$V2+offset+0.5)/ntperinch,o1,segoffsets[rev$V3]+(rev$V2+offset-0.5)/ntperinch,o1-rev$V1/sc,col=col3[(rev$V2+phaseoffset)%%3+1],border=FALSE)
}
lines(c(ml,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch),c(o1,o1),col="grey")

rect(x1,o1-1,x1+ml,o1+0.9,col="white",border=FALSE)
rect(x2-mr,o1-1,x2,o1+0.9,col="white",border=FALSE)

text(x1+0.4*ml,o1,labels="ttt",adj=c(0,0.5),srt=90)
text(x2-mr*0.8,o1+c(0,yh)/sc,labels=c("0",yh),adj=c(0,0.5))
arrows(x2-mr*0.95,o1+c(0,yh)/sc,x2-mr*0.85,o1+c(0,yh)/sc,length=0)
text(srt=270,x2-mr*0.15,labels="RPM",o1+0.4)

#------------------------------------------------------------------------------

