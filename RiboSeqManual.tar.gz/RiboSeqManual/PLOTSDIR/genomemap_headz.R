arrows(dotlines,-1*nsamples+0.3,dotlines,0.5*map_height,col=colDot,lty="dotted",length=0)
phaseoffset = ppp
rect(x1,-nsamples*1,x1+ml,map_height,col="white",border=FALSE)
rect(x2-mr,-nsamples*1,x2,map_height,col="white",border=FALSE)

#------------------------------------------------------------------------------
