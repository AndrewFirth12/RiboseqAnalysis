#Right margin or spacer filler
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

#------------------------------------------------------------------------------
