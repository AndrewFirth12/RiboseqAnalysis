st <- read.table("lll/starts_stops_length.total")
s1a <- st[st$V1 < 410 , ]
h1a = hist(s1a$V1,breaks=c(-100:410)+0.5,plot=FALSE)
s1b <- st[st$V2 > -210 , ]
h1b = hist(s1b$V2,breaks=c(-210:100)+0.5,plot=FALSE)
y1 = 1.1*max(h1a$counts,h1b$counts)
rect(h1a$mids-0.5,nsamples-ccc,h1a$mids+0.5,nsamples-ccc+h1a$counts/y1,border=FALSE,col=col3[(h1a$mids+900)%%3+1])
text(25,nsamples-ccc+0.9,labels="ttt",adj=c(0,0.5))

