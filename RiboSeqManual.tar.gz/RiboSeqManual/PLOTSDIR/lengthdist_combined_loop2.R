mRNA = read.table("lll/lenhist.mRNA.qqq")
lines(mRNA$V2,mRNA$V1/sum(mRNA$V1),col=rainbow(nsamples)[ccc])
text(m1-0.03*(m1-p1),(1+0.5/nsamples-ccc/nsamples)*y2,"ddd",adj=c(1.0,0.5),col=rainbow(nsamples)[ccc])

