y2 = 0

tmar = 0.017
bmar = 0.48
lmar = 0.2
rmar = 0.02
nsamples = nnn
minlen = ppp
maxlen = mmm
ncolumns = aaa
nrows = ceiling(nsamples/ncolumns)

bitmap("ggg.vlengthdist.jpg",type="jpeg",height=tmar+bmar+nrows,width=lmar+rmar+ncolumns,res=600,pointsize=12)
layout(matrix(c(1+0*c(1:(ncolumns+2))lll), nrows+2, ncolumns+2, byrow = TRUE), c(lmar,1+c(1:ncolumns)*0,rmar),c(tmar,1+c(1:nrows)*0,bmar))

temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)
par(mgp=c(0,0.4,0))
par(tcl=-0.3)

#Top margin
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

#Left margin
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.4,0.5,labels="Relative fraction",adj=c(0.5,0.5),srt=90)

#------------------------------------------------------------------------------
