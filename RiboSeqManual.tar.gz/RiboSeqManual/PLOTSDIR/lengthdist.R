bitmap("lll/lengthdist.jpg",type="jpeg",height=2,width=3,res=600,pointsize=12)

layout(matrix(c(1,2,3,4,5,6,7,8,9), 3, 3, byrow = TRUE), c(0.14,1,0.03), c(0.15,1,0.24))

temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)
par(mgp=c(0,0.4,0))
par(tcl=-0.3)

mRNAtotal = read.table("lll/lenhist.mRNA.total")
mRNAuniq  = read.table("lll/lenhist.mRNA.unique")

#Read in virus reads if > 500 reads.
#fwd vRNAtotal_fwd = read.table("lll/lenhist.vRNA_genome.fwd.total")
#rev vRNAtotal_rev = read.table("lll/lenhist.vRNA_genome.rev.total")
#Rescale virus reads so they have the same total area as host mRNA total
#fwd vRNAtotal_fwd$V1 = vRNAtotal_fwd$V1 * (sum(mRNAtotal$V1)/sum(vRNAtotal_fwd$V1))
#rev vRNAtotal_rev$V1 = vRNAtotal_rev$V1 * (sum(mRNAtotal$V1)/sum(vRNAtotal_rev$V1))

y2 = max(mRNAtotal$V1,mRNAuniq$V1)
#fwd y2 = max(mRNAtotal$V1,mRNAuniq$V1,vRNAtotal_fwd$V1)
#rev y2 = max(mRNAtotal$V1,mRNAuniq$V1,vRNAtotal_rev$V1)
#fwd #rev y2 = max(mRNAtotal$V1,mRNAuniq$V1,vRNAtotal_fwd$V1,vRNAtotal_rev$V1)
y2 = y2 * 1.05

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.5,labels="ttt",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.15,0.5,labels="host CDS counts",adj=c(0.5,0.5),srt=90)

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(ppp,mmm),ylim=c(0,y2))

#rev lines(vRNAtotal_rev$V2,vRNAtotal_rev$V1,col=colors()[129],lty="dashed")
#fwd lines(vRNAtotal_fwd$V2,vRNAtotal_fwd$V1,col=colors()[34],lty="dashed")
lines(mRNAtotal$V2,mRNAtotal$V1,col=colors()[645])
lines(mRNAuniq$V2,mRNAuniq$V1,col=colors()[573])

text(mmm-0.03*(mmm-ppp),0.9*y2,"all mRNA reads",adj=c(1.0,0.5),col=colors()[645])
text(mmm-0.03*(mmm-ppp),0.8*y2,"unique mRNA reads",adj=c(1.0,0.5),col=colors()[573])
#fwd text(mmm-0.03*(mmm-ppp),0.7*y2,"(+) virus reads (scaled)",adj=c(1.0,0.5),col=colors()[34])
#rev text(mmm-0.03*(mmm-ppp),0.6*y2,"(-) virus reads (scaled)",adj=c(1.0,0.5),col=colors()[129])

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.18,labels="read length (nt)",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

dev.off()

