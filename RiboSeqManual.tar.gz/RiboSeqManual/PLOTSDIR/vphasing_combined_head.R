lmar = 1.50
rmar = 0.02

bitmap("ggg.vphasing_combined.jpg",type="jpeg",height=3.077,width=0.3*(lmar+nnn+rmar),res=600,pointsize=12)

col3 = c(colors()[84],colors()[121],colors()[499])
temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)

layout(matrix(c(1,1,1,2,4,3,5,5,6), 3, 3, byrow = TRUE), c(lmar,nnn,rmar), c(0.17,2,1.6))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#title
text(0.5,0.5,labels="ggg",adj=c(0.5,0.5))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#left margin
text(0.5,0.65,labels="host",srt=90,adj=c(0.5,0.5))
text(0.5,0.15,labels="virus",srt=90,adj=c(0.5,0.5))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#right margin

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(0,nnn),ylim=c(-1,1),axes=FALSE)
#phasing plots

