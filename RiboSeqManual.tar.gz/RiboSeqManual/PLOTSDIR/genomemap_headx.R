arrows(dotlines,-1*nsamples+0.3,dotlines,0.5*map_height,col=colDot,lty="dotted",length=0)

#------------------------------------------------------------------------------
