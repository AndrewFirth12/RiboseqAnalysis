#------------------------------------------------------------------------------
#Parameters for genome map plot

colDot = "purple"      #colour for the vertical dotted lines
colCDS = "light blue"  #colour for CDSs
colUTR = "black"       #colours for UTRs

ml = 0.14            #left margin (inches)
mr = 0.55            #right margin (inches)
sp = 0.28            #spacer between segments, if applicable (inches)

#@@1#ntperinch = 1400     #nucleotides per inch (full-genome plot)
#@@2#ntperinch = qqq      #nucleotides per inch (zoom-in plot)

map_height = 1.0     #heigth of the genome map part of the plot (inches); you
                     #  can increase this if you want to add extra annotation
                     #  e.g. sgRNA transcript diagrams

#------------------------------------------------------------------------------
#Parameters for plotting RNASeq and RiboSeq data

#nt offset applied to read 5' end coords to map approximate P-site
offset = 12

#phasing colours (where applicable)
col3 = c(colors()[84],colors()[121],colors()[499])

#------------------------------------------------------------------------------

nsamples = nnn
seglengths = c(aaa)
segnames = c(bbb)
nsegments = length(seglengths)

#Offset in inches to the zero-point (i.e. nt 1) of each segment
v1 = cumsum(seglengths)
v2 = c(1:nsegments)-1
if (nsegments > 1) {
  v2[c(2:nsegments)] = v1[c(1:nsegments-1)]
}
segoffsets = ml+v2/ntperinch+(c(1:nsegments)-1)*sp

#@@1#bitmap("genomemap.jpg",type="jpeg",width=ml+mr+(nsegments-1)*sp+sum(seglengths)/ntperinch,height=map_height+nsamples*1,res=600,pointsize=12)
#@@2#bitmap("genomemap.jpg",type="jpeg",width=ml+mr+(jjj-iii+1)/ntperinch,height=map_height+nsamples*1,res=600,pointsize=12)


par(xaxs="i")
par(yaxs="i")
par(cex=0.7)
par(mar=c(0,0,0,0))
temp=c(0,1)

#Plot dimensions are all measured in inches

#@@1#plot(temp,temp,type="n",xlab="",ylab="",xaxt="n",yaxt="n",xlim=c(0,ml+mr+(nsegments-1)*sp+sum(seglengths)/ntperinch),ylim=c(-nsamples*1,map_height),axes=FALSE)

#@@2#if (sss > 1) {
#@@2#  segsum = sum(seglengths[1:(sss-1)])
#@@2#} else {
#@@2#  segsum = 0
#@@2#}
#@@2#x1 = (sss-1)*sp+(iii+segsum)/ntperinch
#@@2#x2 = ml+(sss-1)*sp+(jjj+segsum)/ntperinch+mr
#@@2#plot(temp,temp,type="n",xlab="",ylab="",xaxt="n",yaxt="n",xlim=c(x1,x2),ylim=c(-nsamples*1,map_height),axes=FALSE)


#RNA (UTRs)
rect(segoffsets,0.5*map_height-0.03,segoffsets+seglengths/ntperinch,0.5*map_height+0.03,col=colUTR,border=FALSE)
text(segoffsets,0.5*map_height,labels=expression(paste("5",symbol("\242"))),adj=c(1.2,0.5))
text(segoffsets+seglengths/ntperinch,0.5*map_height,labels=expression(paste("3",symbol("\242"))),adj=c(-0.2,0.5))

dotlines = c(-999)

#------------------------------------------------------------------------------
