minlen = ppp
maxlen = 35
lmar = 0.1
rmar = 0.05

bitmap("lll/phasing.jpg",type="jpeg",height=2,width=lmar+0.2*(maxlen-minlen+1)+rmar,res=600,pointsize=12)

phasing = read.table("lll/phasing.txt")
m1 = max(phasing$V2)
m2 = max(phasing$V4)
mm = max(m1,m2)
col3 = c(colors()[84],colors()[121],colors()[499])
temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)

layout(matrix(c(1,1,1,2,3,4,5,5,5,6,7,8,9,10,11), 5, 3, byrow = TRUE), c(lmar,0.2*(maxlen-minlen+1),rmar), c(0.35,1,0.1,1,0.4))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
text(0.5,0.75,labels="Phasing of reads mapping within host CDSs",adj=c(0.5,0.5))
text(0.5,0.25,labels="ttt",adj=c(0.5,0.5))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
text(0.5,0.5,srt=90,labels="total reads",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(minlen,maxlen+1),ylim=c(0,1),axes=FALSE)
rect(0.125+phasing$V1+phasing$V3/4,0,0.125+phasing$V1+(phasing$V3+1)/4,0.9*phasing$V2/mm,col=col3[phasing$V3+1],border=FALSE)

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
text(0.5,0.5,srt=90,labels="unique reads",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(minlen,maxlen+1),ylim=c(0,1),axes=FALSE)
rect(0.125+phasing$V1+phasing$V3/4,0,0.125+phasing$V1+(phasing$V3+1)/4,0.9*phasing$V4/mm,col=col3[phasing$V3+1],border=FALSE)

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n",xlim=c(minlen,maxlen+1))
text(c(minlen:maxlen)+0.5,0.75,labels=c(minlen:maxlen),adj=c(0.5,0.5))
text(0.5*(minlen+maxlen+1),0.25,labels="read length (nt)",adj=c(0.5,0.5))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

dev.off()

