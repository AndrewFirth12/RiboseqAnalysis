lmar = 1.50
rmar = 0.02

bitmap("ggg.phasing_combined.jpg",type="jpeg",height=2.4,width=0.3*(lmar+nnn+rmar),res=600,pointsize=12)

col3 = c(colors()[84],colors()[121],colors()[499])
temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)

layout(matrix(c(1,1,1,2,4,3,5,5,6), 3, 3, byrow = TRUE), c(lmar,nnn,rmar), c(0.34,1,1.6))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#title
text(0.5,0.75,labels="Host CDS phasing",adj=c(0.5,0.5))
text(0.5,0.25,labels="ggg",adj=c(0.5,0.5))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#left margin

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#right margin

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(0,nnn),ylim=c(0,1),axes=FALSE)
#phasing plot

