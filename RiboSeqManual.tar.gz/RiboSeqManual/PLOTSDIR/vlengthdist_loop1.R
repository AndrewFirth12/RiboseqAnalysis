mRNAtotal = read.table("lll/lenhist.mRNA.total")
vRNAtotal = read.table("lll/lenhist.vRNA.total")

#Rescale virus reads to unit total area
mRNAtotal$V1 = mRNAtotal$V1 / sum(mRNAtotal$V1)
vRNAtotal$V1 = vRNAtotal$V1 / sum(vRNAtotal$V1)

y2 = max(y2,max(mRNAtotal$V1),max(vRNAtotal$V1))

#------------------------------------------------------------------------------
