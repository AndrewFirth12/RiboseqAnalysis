
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.18,labels="read length (nt)",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

dev.off()
