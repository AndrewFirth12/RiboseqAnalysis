y_fwd = 0
if (file.info("PhasingFiles/lll.fwd.www")$size != 0) {
  fwd <- read.table("PhasingFiles/lll.fwd.www")
  y_fwd = 1
}

o1 = -1*ccc + 0.3
sc = 3*12

if (y_fwd) {
  rect(segoffsets[fwd$V3]+(fwd$V2+offset)/ntperinch,o1+fwd$V4/3,segoffsets[fwd$V3]+(fwd$V2+offset)/ntperinch,o1+fwd$V4/3+log(1+fwd$V1)/sc,col=col3[fwd$V4+1],border=col3[fwd$V4+1])
}

text(ml,o1+0.8,labels="ttt",adj=c(0,0.5))
text(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.2,o1+0/3+log(1+c(1,1000))/sc,labels=c("1",expression(10^3)),adj=c(0,0.5))
text(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.2,o1+1/3+log(1+c(1,1000))/sc,labels=c("1",expression(10^3)),adj=c(0,0.5))
text(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.2,o1+2/3+log(1+c(1,1000))/sc,labels=c("1",expression(10^3)),adj=c(0,0.5))
arrows(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.05,o1+0/3+log(1+c(1,10,100,1000))/sc,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.15,o1+0/3+log(1+c(1,10,100,1000))/sc,length=0)
arrows(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.05,o1+1/3+log(1+c(1,10,100,1000))/sc,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.15,o1+1/3+log(1+c(1,10,100,1000))/sc,length=0)
arrows(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.05,o1+2/3+log(1+c(1,10,100,1000))/sc,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.15,o1+2/3+log(1+c(1,10,100,1000))/sc,length=0)
text(srt=270,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.85,labels="RPM",o1+0.4)

#------------------------------------------------------------------------------


