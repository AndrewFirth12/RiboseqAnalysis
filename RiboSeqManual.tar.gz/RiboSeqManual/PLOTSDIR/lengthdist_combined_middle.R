
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.5,labels="ggg",adj=c(0.5,0.5))

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.15,0.5,labels="relative abundance",adj=c(0.5,0.5),srt=90)

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(p1,m1),ylim=c(0,y2))
