readcounts = read.table("ggg.readcounts.txt")
nsamples = nrow(readcounts)
temp = c(0,1)
par(xaxs="i")
par(cex.axis=1.0)

bitmap("ggg.readcounts.jpg",type="jpeg",width=5,height=0.6*(nsamples+2.0),res=600,pointsize=10)

par(mar=c(0,0,0,0))
plot(temp,temp,type="n",ylab="",xlab="",main="",ylim=c(0.18,nsamples+2.0+0.18),xlim=c(-0.05,1.05),axes=FALSE)

#All reads
rect(0,c(1:nsamples)-0.8,readcounts$V3/readcounts$V3,c(1:nsamples)-0.2)

base = 0

#'too-short' reads
rect(base,c(1:nsamples)-0.8,base+readcounts$V4/readcounts$V3,c(1:nsamples)-0.2,col=colors()[19])
base = base + readcounts$V4/readcounts$V3

#'adapter-only' reads
rect(base,c(1:nsamples)-0.8,base+readcounts$V5/readcounts$V3,c(1:nsamples)-0.2,col=colors()[15])
base = base + readcounts$V5/readcounts$V3

#'non-clipped' reads
rect(base,c(1:nsamples)-0.8,base+readcounts$V6/readcounts$V3,c(1:nsamples)-0.2,col=colors()[18])
base = base + readcounts$V6/readcounts$V3

#'duplicate' reads
rect(base,c(1:nsamples)-0.8,base+readcounts$V7/readcounts$V3,c(1:nsamples)-0.2,col=colors()[419])
base = base + readcounts$V7/readcounts$V3

text(0.0,c(1:nsamples)-0.07,labels=readcounts$V2,adj=0.0,cex=0.8)
text(1.0,c(1:nsamples)-0.07,labels=paste("[",readcounts$V3," reads ]"),adj=1.0,cex=0.8)
text(0.5,nsamples+2.18,labels="ggg",adj=0.5,cex=1.2,font=2)

x1 = 0.1
cc1 = 0.8
y0 = 1.65
yd = 1.5/6
y1 = 0.65/6

rect(0.0+x1,nsamples+y0-0*yd+y1,0.1+x1,nsamples+y0-0*yd-y1,col=colors()[19])
rect(0.0+x1,nsamples+y0-1*yd+y1,0.1+x1,nsamples+y0-1*yd-y1,col=colors()[15])
rect(0.0+x1,nsamples+y0-2*yd+y1,0.1+x1,nsamples+y0-2*yd-y1,col=colors()[18])
rect(0.0+x1,nsamples+y0-3*yd+y1,0.1+x1,nsamples+y0-3*yd-y1,col=colors()[419])
rect(0.0+x1,nsamples+y0-4*yd+y1,0.1+x1,nsamples+y0-4*yd-y1,col=colors()[315])
rect(0.0+x1,nsamples+y0-5*yd+y1,0.1+x1,nsamples+y0-5*yd-y1,col="white")

text(0.12+x1,nsamples+y0-0*yd,adj=0.0,labels="too-short reads",cex=cc1)
text(0.12+x1,nsamples+y0-1*yd,adj=0.0,labels="adapter-only reads",cex=cc1)
text(0.12+x1,nsamples+y0-2*yd,adj=0.0,labels="non-clipped reads",cex=cc1)
text(0.12+x1,nsamples+y0-3*yd,adj=0.0,labels="duplicate reads",cex=cc1)
text(0.12+x1,nsamples+y0-4*yd,adj=0.0,labels="reverse sense matches",cex=cc1)
text(0.12+x1,nsamples+y0-5*yd,adj=0.0,labels="unmapped reads",cex=cc1)

x1 = 0.65
yd = 1.5/nnn
y1 = 0.65/nnn

#------------------------------------------------------------------------------
#Add lines for each database (rRNA, mRNA etc) here:

