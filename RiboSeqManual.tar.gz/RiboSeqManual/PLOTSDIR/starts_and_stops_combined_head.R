tmar = 0.2
bmar = 0.7
nsamples = nnn

bitmap("ggg.starts_and_stops.jpg",type="jpeg",height=tmar+nsamples+bmar,width=5,res=600,pointsize=12)

col3 = c(colors()[84],colors()[121],colors()[499])
temp=c(0,1)
par(xaxs="i")
par(yaxs="i")
par(cex=0.7)
par(mar=c(0,0,0,0))
par(mgp=c(3,1.8,1))

f1 = 460
f2 = 220

layout(matrix(c(1,2,5,1,6,5,1,3,5,1,7,5,1,4,5), 3, 5, byrow = FALSE), c(5,f1,50,f2,5), c(tmar,nsamples,bmar))

#  1   1   1   1   1
#  2   6   3   7   4
#  5   5   5   5   5

#top margin
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
text(0.5,0.5,adj=c(0.5,0.5),labels="ggg")

#left, centre and right spacers
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

#bottom margin
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
text(0.5,0.10,adj=c(0.5,0.5),labels=expression(paste("location of 5",symbol("\242")," end of reads relative to host mRNA start and stop codons")))

plot(temp,temp,type="n",xlab="",ylab="",main="",xlim=c(-60,400),ylim=c(0,nsamples),axes=FALSE)
axis(side=1,labels=c("start","100","200","300","400"),at=c(0,100,200,300,400))

