
plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")
#bottom right corner

dev.off()
