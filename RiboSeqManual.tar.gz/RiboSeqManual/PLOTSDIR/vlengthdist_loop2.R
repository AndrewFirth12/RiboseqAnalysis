mRNAtotal = read.table("lll/lenhist.mRNA.total")
vRNAtotal = read.table("lll/lenhist.vRNA.total")

#Rescale virus reads to unit total area
mRNAtotal$V1 = mRNAtotal$V1 / sum(mRNAtotal$V1)
vRNAtotal$V1 = vRNAtotal$V1 / sum(vRNAtotal$V1)

plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(minlen,maxlen),ylim=c(0,1.1*y2),xaxt="n",yaxt="n")
text(minlen+0.98*(maxlen-minlen),1.02*y2,labels="ttt",adj=c(1,0.5))

lines(mRNAtotal$V2,mRNAtotal$V1,col=colors()[645])
lines(vRNAtotal$V2,vRNAtotal$V1,col=colors()[34])

#------------------------------------------------------------------------------
