#ggg

#"dotlines" is not used in the genome map but is ready to be used in the
#  RiboSeq/RNASeq mapped-to-genome plots.
dotlines = as.vector(rbind(dotlines,segoffsets[ccc]+c(ddd)/ntperinch)) 
dotlines = as.vector(rbind(dotlines,segoffsets[ccc]+c(eee)/ntperinch)) 

#Reading frame offset so that longest CDS is in the 0 frame, and the other two
#  frames are plotted above (+1) or below (-1) the zero frame
fo = (c(ddd)%%3-fff+1)%%3-1

rect(segoffsets[ccc]+c(ddd)/ntperinch,0.5*map_height+0.09*fo-0.09,segoffsets[ccc]+c(eee)/ntperinch,0.5*map_height+0.09*fo+0.09,col=colCDS,border="black")

text(segoffsets[ccc]+0.5*(c(ddd)+c(eee))/ntperinch,0.5*map_height+0.09*fo,labels=c(hhh),adj=c(0.5,0.5))

#------------------------------------------------------------------------------
