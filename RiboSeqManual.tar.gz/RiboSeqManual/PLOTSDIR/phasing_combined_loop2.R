text(ccc-0.5,0.95,labels="ttt",adj=c(1,0.5),srt=60)
