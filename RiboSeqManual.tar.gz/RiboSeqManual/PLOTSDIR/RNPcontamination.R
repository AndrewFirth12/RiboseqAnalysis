bitmap("lll/RNP.mmm.jpg",type="jpeg",height=2.4,width=4,res=600,pointsize=12)

layout(matrix(c(1,1,2,3), 2, 2, byrow = TRUE), c(1,1), c(0.25,1))

temp = c(0,1)
par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)

plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.7,labels="ttt")
text(0.5,0.3,labels="mmm reads mapping to host mRNAs\n(-100,-10) and (+10,+100) around stop codons")

cds = read.table("lll/RNP.mmm.cds")
utr = read.table("lll/RNP.mmm.utr")
maxcts = max(cds$V2,utr$V2)
ymax1 = max(cds$V2/max(1,sum(cds$V2)),utr$V2/max(1,sum(utr$V2)))

par(mar=c(4,4,1,2))

plot(temp,temp,type="n",ylab="absolute counts",xlab="read length (nt)",main="",xlim=c(ppp,50),ylim=c(0,maxcts))
lines(cds$V1,cds$V2,col=colors()[657])
lines(utr$V1,utr$V2,col=colors()[35])
text(48.5,maxcts*0.95,labels="CDS",adj=c(1.0,0.5),col=colors()[657])
text(48.5,maxcts*0.85,labels=expression(paste("3",symbol("\242")," UTR")),adj=c(1.0,0.5),col=colors()[35])

plot(temp,temp,type="n",ylab="normalized counts",xlab="read length (nt)",main="",xlim=c(ppp,50),ylim=c(0,ymax1))
lines(cds$V1,cds$V2/max(1,sum(cds$V2)),col=colors()[657])
lines(utr$V1,utr$V2/max(1,sum(utr$V2)),col=colors()[35])
text(48.5,ymax1*0.95,labels="CDS",adj=c(1.0,0.5),col=colors()[657])
text(48.5,ymax1*0.85,labels=expression(paste("3",symbol("\242")," UTR")),adj=c(1.0,0.5),col=colors()[35])
dev.off()
