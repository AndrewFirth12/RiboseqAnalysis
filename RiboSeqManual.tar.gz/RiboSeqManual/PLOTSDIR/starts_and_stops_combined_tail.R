axis(side=1,labels=c("-200","-100","stop"),at=c(-200,-100,0))

plot(temp,temp,axes=FALSE,ylab="",xlab="",main="",type="n")

dev.off()
