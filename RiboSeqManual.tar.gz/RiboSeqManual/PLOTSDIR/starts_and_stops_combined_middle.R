plot(temp,temp,type="n",xlab="",ylab="",main="",xlim=c(-200,20),ylim=c(0,nsamples),axes=FALSE)
axis(side=1,labels=c("-200","-100","stop"),at=c(-200,-100,0))

