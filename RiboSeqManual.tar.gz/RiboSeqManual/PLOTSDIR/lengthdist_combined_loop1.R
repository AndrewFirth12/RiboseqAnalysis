mRNA = read.table("lll/lenhist.mRNA.qqq")
y2 = max(y2,1.05*mRNA$V1/sum(mRNA$V1))

