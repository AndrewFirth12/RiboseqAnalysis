bitmap("ggg.lengthdist_combined.qqq.jpg",type="jpeg",height=2,width=3,res=600,pointsize=12)

layout(matrix(c(1,2,3,4,5,6,7,8,9), 3, 3, byrow = TRUE), c(0.14,1,0.03), c(0.15,1,0.24))

temp = c(0,1)

par(xaxs="i")
par(yaxs="i")
par(mar=c(0,0,0,0))
par(cex=0.7)
par(mgp=c(0,0.4,0))
par(tcl=-0.3)

m1 = mmm
p1 = ppp
nsamples = nnn

y2 = 0

