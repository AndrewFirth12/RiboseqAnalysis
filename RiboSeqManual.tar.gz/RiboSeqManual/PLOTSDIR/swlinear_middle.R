y_fwd = 0
y_rev = 0
if (file.info("SlidingWindowFiles/lll.fwd.www")$size != 0) {
  fwd <- read.table("SlidingWindowFiles/lll.fwd.www")
  y_fwd = 1
}
if (file.info("SlidingWindowFiles/lll.rev.www")$size != 0) {
  rev <- read.table("SlidingWindowFiles/lll.rev.www")
  y_rev = 1
}

o1 = -1*ccc + 0.3

if (y_fwd) {
  sc = 1.05*max(fwd$V1)
} else {
  sc = 1
}
yh = signif(0.8*max(fwd$V1),digits=2)

if (y_fwd) {
  rect(segoffsets[fwd$V3]+(fwd$V2+offset)/ntperinch,o1,segoffsets[fwd$V3]+(fwd$V2+offset)/ntperinch,o1+fwd$V1/sc,col="red",border="red")
}
if (y_rev) {
  rect(segoffsets[rev$V3]+(rev$V2+offset)/ntperinch,o1,segoffsets[rev$V3]+(rev$V2+offset)/ntperinch,o1-rev$V1/sc,col="blue",border="blue")
}

text(ml,o1+0.8,labels="ttt",adj=c(0,0.5))
text(ml*0.5,o1+0,labels="rev   fwd",srt=90)
lines(ml*c(0.3,0.9),c(o1,o1))
text(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.2,o1+c(0,yh)/sc,labels=c("0",yh),adj=c(0,0.5))
arrows(ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.05,o1+c(0,yh)/sc,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.15,o1+c(0,yh)/sc,length=0)
text(srt=270,ml+(nsegments-1)*sp+sum(seglengths)/ntperinch+mr*0.85,labels="RPM",o1+0.4)

#------------------------------------------------------------------------------


