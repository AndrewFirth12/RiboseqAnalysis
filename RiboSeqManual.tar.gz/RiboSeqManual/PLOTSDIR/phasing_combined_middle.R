plot(temp,temp,type="n",ylab="",xlab="",main="",xlim=c(-lmar,nnn),ylim=c(0,1),axes=FALSE)
#sample labels
