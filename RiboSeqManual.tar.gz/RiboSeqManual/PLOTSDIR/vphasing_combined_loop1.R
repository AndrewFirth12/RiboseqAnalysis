phasing = read.table("lll/phasing_total.txt")
phasing = phasing/sum(phasing)
rect(ccc-0.875,0,ccc-0.625,phasing[1],col=col3[1],border=FALSE)
rect(ccc-0.625,0,ccc-0.375,phasing[2],col=col3[2],border=FALSE)
rect(ccc-0.375,0,ccc-0.125,phasing[3],col=col3[3],border=FALSE)

vphasing = read.table("lll/vphasing_total.txt")
vphasing = vphasing/sum(vphasing)
rect(ccc-0.875,-1,ccc-0.625,vphasing[1]-1,col=col3[1],border=FALSE)
rect(ccc-0.625,-1,ccc-0.375,vphasing[2]-1,col=col3[2],border=FALSE)
rect(ccc-0.375,-1,ccc-0.125,vphasing[3]-1,col=col3[3],border=FALSE)

