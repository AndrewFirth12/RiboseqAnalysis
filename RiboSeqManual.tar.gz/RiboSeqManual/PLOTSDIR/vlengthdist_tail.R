#Bottom left corner
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)

#Bottom margin
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)
text(0.5,0.42,labels="Read length (nt)",adj=c(0.5,0.5))
text(0.25,0.12,"host",adj=c(0.5,0.5),col=colors()[645])
text(0.75,0.12,"virus",adj=c(0.5,0.5),col=colors()[34])

#Bottom right corner
plot(temp,temp,type="n",ylab="",xlab="",main="",axes=FALSE)


dev.off()
