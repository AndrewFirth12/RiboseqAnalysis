bitmap("lll/PCR_degeneracy.jpg",type="jpeg",height=3,width=5.2,res=600,pointsize=12)

par(xaxs="i")
par(yaxs="i")
par(cex=0.7)
temp = c(0,1)
par(las=2)

stats <- read.table("lll/PCR_degeneracy_sorted.txt")
xmax = max(stats$V2)

par(mar=c(4,5,1.5,1))
plot(temp,temp,type="n",xlim=c(90,max(1000,xmax^1.01)),xlab="Total number of reads mapping within codons 1 to 300",ylab="Number of unique 5' end positions\nin 100 random reads",ylim=c(0,110),main="ttt",log="x",xaxt="n")
axis(side=1,labels=c(expression(10^2),expression(10^3),expression(10^4),expression(10^5)),at=c(100,1000,10000,100000),las=1)
points(stats$V2,stats$V3,pch=21,cex=0.5,col=colors()[26],bg=colors()[121],lwd=0.9)

step = 100
i = 1
while (i < nrow(stats)-2*step)
{  
  lines(c(stats$V2[i],stats$V2[i+step-1]),c(1,1)*mean(stats$V3[i:(i+step-1)]),col="red",lwd=2)
  i = i+step
}
lines(c(stats$V2[i],stats$V2[nrow(stats)]),c(1,1)*mean(stats$V3[i:nrow(stats)]),col="red",lwd=2)

text(95,105,labels="Each point represents a host mRNA",adj=c(0,0.5),col="grey")
text(95,99,labels="Deviation from a horizontal line for lowly expressed genes indicates PCR degeneracy",adj=c(0,0.5),col="grey")
text(95,93,labels="Mean for 100 successive mRNAs",adj=c(0,0.5),col="red")

dev.off()
